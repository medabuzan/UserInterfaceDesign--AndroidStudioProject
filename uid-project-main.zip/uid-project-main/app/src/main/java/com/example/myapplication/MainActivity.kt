package com.example.myapplication

import com.example.myapplication.news.NewsActivity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Toast
import com.example.myapplication.news.NewsActivityAdmin
import com.example.myapplication.news.NewsActivityTeacher

class MainActivity : AppCompatActivity() {
    // Define a data class for User
    data class User(val username: String, val password: String, val role: String)

    val student = User("student", "student", "Student")
    val teacher = User("teacher", "teacher", "Teacher")
    val admin = User("admin", "admin", "Administrator")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val loginButton = findViewById<Button>(R.id.loginButton)
        loginButton.setOnClickListener {
            val usernameInput = findViewById<EditText>(R.id.usernameInput).text.toString()
            val passwordInput = findViewById<EditText>(R.id.passwordInput).text.toString()
            val roleGroup = findViewById<RadioGroup>(R.id.roleGroup)
            val selectedRoleId = roleGroup.checkedRadioButtonId

            val role = when (selectedRoleId) {
                R.id.studentRadio -> "Student"
                R.id.teacherRadio -> "Teacher"
                R.id.adminRadio -> "Administrator"
                else -> ""
            }

            handleLogin(usernameInput, passwordInput, role)
        }
    }

    private fun handleLogin(username: String, password: String, role: String) {
        // Debug output to logcat
        println("Logging in with role: $role, Username: $username")

        if (username == student.username && password == student.password && role == student.role) {
            val intent = Intent(this, NewsActivity::class.java)
            startActivity(intent)
        } else if (username == teacher.username && password == teacher.password && role == teacher.role) {
            val intent = Intent(this, NewsActivityTeacher::class.java)
            startActivity(intent)
        } else if (username == admin.username && password == admin.password && role == admin.role) {
            val intent = Intent(this, NewsActivityAdmin::class.java)
            startActivity(intent)
        } else {
            Toast.makeText(this, "Invalid credentials or role", Toast.LENGTH_SHORT).show()
        }
    }
}
