package com.example.myapplication.news

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.MainActivity
import com.example.myapplication.R

class NewsActivityTeacher : AppCompatActivity() {
    private var sortSelection: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_news_teacher)

        val searchField: EditText = findViewById(R.id.searchField)
        searchField.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {
                filterNews(s.toString())
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
            }
        })

        val spinner: Spinner = findViewById(R.id.spinner_navigation)
        ArrayAdapter.createFromResource(
            this,
            R.array.news_options,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner.adapter = adapter
        }

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, pos: Int, id: Long) {
                when (parent.getItemAtPosition(pos).toString()) {
                    "Filter News" -> navigateToFilterNews()
                    "Urgent" -> navigateToUrgent()
                    "Calendar" -> navigateToCalendar()
                    "Grades" -> navigateToGrades()
                    "Report Bug" -> navigateToReportBug()
                    "Log Out" -> logOut()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Another interface callback
            }
        }
    }

    private fun navigateToFilterNews() {
        // Implement navigation
    }

    private fun navigateToUrgent() {
        // Implement navigation
    }

    private fun navigateToCalendar() {
        // Implement navigation
    }
    private fun navigateToGrades() {
        // Implement navigation
    }
    private fun navigateToReportBug() {
        // Implement navigation
    }

    fun checkAllNotificationsDismissed(popupView: View) {
        val notificationLayout1: LinearLayout = popupView.findViewById(R.id.notificationLayout1)
        val notificationLayout2: LinearLayout = popupView.findViewById(R.id.notificationLayout2)

        if (notificationLayout1.visibility == View.GONE && notificationLayout2.visibility == View.GONE) {
            clearNotifications()
        }
    }

    fun showNotifications(view: View) {
        val inflater: LayoutInflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popupView = inflater.inflate(R.layout.notification_popup, null)

        val width = LinearLayout.LayoutParams.WRAP_CONTENT
        val height = LinearLayout.LayoutParams.WRAP_CONTENT
        val focusable = true
        val popupWindow = PopupWindow(popupView, width, height, focusable)

        popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0)

        val closeNotification1: ImageView = popupView.findViewById(R.id.closeNotification1)
        closeNotification1.setOnClickListener {
            val notificationLayout1: LinearLayout = popupView.findViewById(R.id.notificationLayout1)
            notificationLayout1.visibility = View.GONE

            checkAllNotificationsDismissed(popupView)
        }

        val closeNotification2: ImageView = popupView.findViewById(R.id.closeNotification2)
        closeNotification2.setOnClickListener {
            val notificationLayout2: LinearLayout = popupView.findViewById(R.id.notificationLayout2)
            notificationLayout2.visibility = View.GONE

            checkAllNotificationsDismissed(popupView)
        }
    }

    fun showSortPopup(view: View) {
        val inflater: LayoutInflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popupView = inflater.inflate(R.layout.sort_popup, null)

        val popupWindow = PopupWindow(popupView, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, true)

        val sortAZ: Button = popupView.findViewById(R.id.sortAZ)
        val sortZA: Button = popupView.findViewById(R.id.sortZA)
        val sortButton: Button = popupView.findViewById(R.id.sortButton)

        sortAZ.setOnClickListener {
            it.isSelected = !it.isSelected
            sortZA.isSelected = false
            sortSelection = if(it.isSelected) "AZ" else null
        }

        sortZA.setOnClickListener {
            it.isSelected = !it.isSelected
            sortAZ.isSelected = false
            sortSelection = if(it.isSelected) "ZA" else null
        }

        sortButton.setOnClickListener {
            popupWindow.dismiss()
        }

        popupWindow.showAsDropDown(view)
    }

    fun clearNotifications() {
        val notificationIcon: ImageView = findViewById(R.id.notificationIcon)
        notificationIcon.setColorFilter(Color.LTGRAY)
    }

    private fun filterNews(query: String) {
        val newsLayout: LinearLayout = findViewById(R.id.newsLayout)
        for (i in 0 until newsLayout.childCount) {
            val view = newsLayout.getChildAt(i)
            if (view is TextView && view.text.contains(query, ignoreCase = true)) {
                view.visibility = View.VISIBLE
            } else if (view is TextView) {
                view.visibility = View.GONE
            }
        }
    }

    private fun logOut() {
        val intent = Intent(this,MainActivity::class.java)
        startActivity(intent)
        finish()
    }
}
